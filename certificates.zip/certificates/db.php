<?php
$host="localhost";
$user="root";
$pass="";
$db="edodwaja_certi";


$host = "localhost";
$user = "u472303742_Pa32X";
$pass = "";
$db = "u472303742_5qCGJ";
$conn=mysqli_connect($host,$user,$pass,$db);
if($conn){
    // echo " success";
}
else{
    echo(die(mysqli_err($conn)));
}

 ?>