import React, { useState } from 'react'
import Calender from './components/Calender'
import moment from 'moment';

import "./style.css"
const App = () => {
    const [value,setValue] = useState(moment())
  return (
    <div>
        <Calender value = {value} setValue={setValue}/>
     
    </div>
  )
}

export default App


//Array of Array is data stucture 