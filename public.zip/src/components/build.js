export default function buildCalender(value){
    //const value = moment()
    //Getting Start Day of Month
    const startDay = value.clone().startOf("month").startOf("week")
    //Getting End Day of Month
    const endDay = value.clone().endOf("month").endOf("week")
    //day is local to this
    const day = startDay.clone().subtract(1,"day")
    const calendar = [];
while(day.isBefore(endDay,"day")){
calendar.push(
    Array(7)
    .fill(0)
    .map(()=>day.add(1,"day").clone())
);
}
return calendar;
}