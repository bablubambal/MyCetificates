import React from 'react'

const DayEvents = ({event}) => {
    const {data,date}=event
    console.log("my events on the ",data,"are ",date)
  return (
    <>
  
    <span className='appointment-event'>{data}</span>
      
    </>
  )
}

export default DayEvents
