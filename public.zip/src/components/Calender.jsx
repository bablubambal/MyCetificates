import React, { useEffect, useState } from 'react'

import "./Calender.css"
import buildCalender from './build';
import dayStyles, {beforeToday} from './styles';
import HeaderCalender from './HeaderCalender';
import Days from 'react-calendar/dist/umd/MonthView/Days';
import DayEvents from './DayEvents';
const Calender = ({value,setValue}) => {

    const [calendar,setCalendar] = useState([])
   // const [value,setValue]  = useState(moment())

   let myEvents = [{date:"07/02/2022",data:"Bablu"},{date:"08/02/2022",data:"Banti"},{date:"07/02/2022",data:"Moiht"}, {date:"09/02/2022",data:"my today event"},{date:"10/02/2022",data:"team meeting"},
   {date:"07/03/2022",data:"Bablu"}]

   const getEventsofDay =(date,myEvents)=>{
     let mydata= myEvents.filter((event)=>  event.date ==date)
    //  function checkData(data){
    //    return data.date == "07/02/2022"
    //  }
    // console.log("my events",mydata)
    //  myEvents.filter(myEvents.date == date)
    return mydata

   }
  //  getEventsofDay("07/02/2022",myEvents)
  // console.log("My Events Filter: ", getEventsofDay("07/02/2022",myEvents))

    
    //const calendar = []
    useEffect(()=>{
        setCalendar(buildCalender(value));
    },[value])

  

  return (
    <div className='calender'>
      {/* Start Date : {startDay.format("MM/DD")}
      End Date : {endDay.format("MM/DD")}
      End Date : {day.format("MM/DD")} */}
      <HeaderCalender value = {value} setValue = {setValue} /> 

      <div className="calender-body">
          <div className="day-names week">
              {
                  ["S","M","T","W","Th","F","Sa"].map(d=><div className='weekdays'>
                      {d}

                  </div>)
              }
          </div>
      {
          calendar.map(week=><div className='week'>{
              week.map(day=> <div className='day'
              onClick={()=> !beforeToday(day) && setValue(day)}
              >
                <div>
                <div className={dayStyles(day,value)} > {day.format("D").toString()
                
                } 
                {/* //  console.log(day.format("DD/MM/YYYY").toString()) */}</div>
                <div className="heloo">
                  
                  {
                // console.log( "Event on the ",day.format("DD/MM/YYYY").toString(), getEventsofDay(day.format("DD/MM/YYYY").toString(),myEvents)?.map(e=> <DayEvents events={e} />))
                getEventsofDay(day.format("DD/MM/YYYY").toString(),myEvents)?.map(e=> {
                  // console.log(e.date)
                  return (
                    <DayEvents event ={e}  />
                  )
                }
               )
              }
                </div>
                 </div>
                {/* <div className={value.isSame(day,"day")?"selected":""} > {day.format("D").toString()}</div>  */}
              </div>)
          }</div>)
      }
      </div>
      

    </div>
  )
}

export default Calender
